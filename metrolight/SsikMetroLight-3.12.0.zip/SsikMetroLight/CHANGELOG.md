## SsikMetroLight 2.0.1
*  Minor fixes.

## SsikMetroLight 2.1.0
* Added option to activate dropdown menu function
* New color settings added
* and also small fixes

## SsikMetroLight 2.1.1
* Compatibility with Shopware 6.4.8.0
* Web Fonts are now loaded from a local server
* and also small fixes

## SsikMetroLight 2.1.2
* Compatibility with Shopware 6.4.9.0

## SsikMetroLight 2.1.3
* Compatibility with Shopware 6.4.11.1

## SsikMetroLight 2.1.4
*  The latest version contains bug fixes and performance improvements
## SsikMetroLight 2.1.5
*  The latest version contains bug fixes and performance improvements
## SsikMetroLight 2.1.6
*  The latest version contains bug fixes and performance improvements
## SsikMetroLight 2.1.7
*  The latest version contains bug fixes and performance improvements
## SsikMetroLight 2.1.8
*  The latest version contains bug fixes and performance improvements
## SsikMetroLight 2.1.9
* Compatibility with Shopware 6.4.13.0
## SsikMagicTheme 2.2.0
* Added new configuration settings/neue Konfigurationseinstellungen hinzugefügt
* Added a new CMS block to create an image slider with content/Einen neuen CMS-Block hinzugefügt, um einen Bild-Slider mit Inhalt zu erstellen
* Fixed the error of manually entering the quantity of goods added to the cart/Der Fehler bei der manuellen Eingabe der Menge der dem Warenkorb hinzugefügten Waren wurde behoben
* and other small bug fixes and performance improvements/und andere kleine Fehlerbehebungen und Leistungsverbesserungen
## SsikMetroLight 2.2.1
*  The latest version contains bug fixes and performance improvements
## SsikMetroLight 2.2.2
* Compatibility with Shopware 6.4.15.0
## SsikMetroLight 2.2.3
* Compatibility with Shopware 6.4.15.2
## SsikMetroLight 3.0.0
* New version v3.0.0
## SsikMetroLight 3.0.1
*  The latest version contains bug fixes and performance improvements
## SsikMetroLight 3.0.2
*  The latest version contains bug fixes and performance improvements
## SsikMetroLight 3.0.3
*  The latest version contains bug fixes and performance improvements
## SsikMetroLight 3.0.4
*  The latest version contains bug fixes and performance improvements
## SsikMetroLight 3.0.5
*  The latest version contains bug fixes and performance improvements
## SsikMetroLight 3.0.6
*  The latest version contains bug fixes and performance improvements
## SsikMetroLight 3.0.7
*  The latest version contains bug fixes and performance improvements
## SsikMetroLight 3.1.0
*  The latest version contains bug fixes and performance improvements
## SsikMetroLight 3.1.1
*  The latest version contains bug fixes and performance improvements
## SsikMetroLight 3.1.2
*  The latest version contains bug fixes and performance improvements
## SsikMetroLight 3.1.3
*  The latest version contains bug fixes and performance improvements
## SsikMetroLight 3.1.4
*  The latest version contains bug fixes and performance improvements
## SsikMetroLight 3.1.5
*  The latest version contains bug fixes and performance improvements
## SsikMetroLight 3.1.6
*  The latest version contains bug fixes and performance improvements
## SsikMetroLight 3.1.7
*  The latest version contains bug fixes and performance improvements
## SsikMetroLight 3.1.8
*  The latest version contains bug fixes and performance improvements
## SsikMetroLight 3.1.9
*  The latest version contains bug fixes and performance improvements
## SsikMetroLight 3.2.0
*  Compatibility with Shopware 6.5.0.0
## SsikMetroLight 3.2.1
*  The latest version contains bug fixes and performance improvements
## SsikMetroLight 3.2.2
*  The latest version contains bug fixes and performance improvements
## SsikMetroLight 3.3.0
*  The latest version contains bug fixes and performance improvements
## SsikMetroLight 3.4.0
*  The latest version contains bug fixes and performance improvements
## SsikMetroLight 3.5.0
*  The latest version contains bug fixes and performance improvements
## SsikMetroLight 3.6.0
*  The latest version contains bug fixes and performance improvements
## SsikMetroLight 3.7.0
*  The latest version contains bug fixes and performance improvements
## SsikMetroLight 3.8.0
*  The latest version contains bug fixes and performance improvements
## SsikMetroLight 3.9.0
*  The latest version contains bug fixes and performance improvements
## SsikMetroLight 3.10.0
* Added ability to install Google Tag Manager / Möglichkeit zur Installation von Google Tag Manager hinzugefügt
## SsikMetroLight 3.11.0
*  The latest version contains bug fixes and performance improvements
## SsikMetroLight 3.12.0
*  The latest version contains bug fixes and performance improvements